import React from 'react'

function ProductDetail() {
  return (
    <h1>Product Details</h1>
  )
}

export default ProductDetail