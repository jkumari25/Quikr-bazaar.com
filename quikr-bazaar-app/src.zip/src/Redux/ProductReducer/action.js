import axios from "axios";
import * as types from "./actionTypes";

const getProduct= (params) => (dispatch) => {
    dispatch({type: types.GET_PRODUCTS_DATA_REQUEST});

    return axios
    .get("https://database-beta.vercel.app/Mobile", params)
    .then((r) =>{
        dispatch({type: types.GET_PRODUCTS_DATA_SUCCESS, payload: r.data});
    })
    .catch((e) =>{
        dispatch({type: types.GET_PRODUCTS_DATA_ERROR})
    })
}

// Single Product

const singleProduct =(id) => (dispatch) =>{
    dispatch({type: types.GET_PRODUCTS_DETAILS_REQUEST});

    return axios
    .get(`https://database-beta.vercel.app/Mobile/${id}`)
    .then((r) =>{
        dispatch({type: types.GET_PRODUCTS_DETAILS_SUCCESS, payload: r.data});
    })
    .catch((e) =>{
        dispatch({type: types.GET_PRODUCTS_DETAILS_ERROR})
    })
}

export { getProduct, singleProduct }