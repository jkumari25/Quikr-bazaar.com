import React from 'react'

function Homepage() {
  return (
    <div>
      <h1>Homepage</h1>
    </div>
  )
}

export default Homepage


