import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import ProductCard from "../Componets/ProductCard";


const SingleProduct = () => {
  const { id } = useParams();
  const product = useSelector((store) => store.product);
  const [singleProduct, setSingleProduct] = useState({});

  // fetch request

  

 
  // store

  useEffect(() => {
    let productData = product.find((el) => el.id === +id);
    productData && setSingleProduct(productData);
  }, []);

  return (
    <div>
      <h1>Single Product {id}</h1>
      <ProductCard singleProduct={singleProduct} />
    </div>
  );
};

export default SingleProduct;
